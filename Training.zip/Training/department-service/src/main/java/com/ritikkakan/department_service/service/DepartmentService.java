package com.ritikkakan.department_service.service;

import com.ritikkakan.department_service.entity.Department;

import java.util.List;

public interface DepartmentService {
    List<Department> getAllDepartment();

    Department getDepartmentById(int id);

    Department saveDepartment(Department department);
}
