package com.ritikkakan.employee_service.service;

import com.ritikkakan.employee_service.entity.Employee;
import com.ritikkakan.employee_service.payload.EmployeeDepartment;

import java.util.List;

public interface EmployeeService {

    List<Employee> getAllEmployee();
    Employee getEmployeeById(int id);

    Employee createEmployee(Employee employee);

    EmployeeDepartment getEmployeeWithDepartment(int employeeId);
}
